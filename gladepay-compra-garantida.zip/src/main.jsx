import React from 'react'
import { createRoot } from 'react-dom/client'
import {
  ShieldCheck, BadgeCheck, LockKeyhole, ArrowUpRight, WalletCards,
  ClipboardCheck, PackageCheck, CircleHelp, ChevronDown, ExternalLink,
  FileText, ShieldAlert, CheckCircle2
} from 'lucide-react'
import './styles.css'

const officialLinks = {
  pix: 'https://www.bcb.gov.br/estabilidadefinanceira/pix-seguranca',
  institutions: 'https://www.bcb.gov.br/estabilidadefinanceira/encontreinstituicao',
  consumerLaw: 'https://www.planalto.gov.br/ccivil_03/leis/l8078compilado.htm',
}

function Header() {
  return (
    <header className="header">
      <a className="brand" href="#inicio" aria-label="GladePay Compra Garantida">
        <span className="brand-mark"><ShieldCheck size={23} strokeWidth={2.3} /></span>
        <span className="brand-copy"><strong>GladePay</strong><small>COMPRA GARANTIDA</small></span>
      </a>
      <span className="header-note"><LockKeyhole size={15} /> Informação e transparência</span>
    </header>
  )
}

function Feature({ icon: Icon, title, children }) {
  return (
    <article className="feature-card">
      <span className="icon-box"><Icon size={22} /></span>
      <h3>{title}</h3>
      <p>{children}</p>
    </article>
  )
}

function Step({ number, icon: Icon, title, children }) {
  return (
    <div className="step">
      <span className="step-number">{number}</span>
      <span className="step-icon"><Icon size={22} /></span>
      <h3>{title}</h3>
      <p>{children}</p>
    </div>
  )
}

function App() {
  return (
    <div id="inicio">
      <Header />
      <main>
        <section className="hero">
          <div className="hero-glow" aria-hidden="true" />
          <div className="hero-content">
            <span className="eyebrow"><span className="eyebrow-dot" /> CENTRAL DE INFORMAÇÕES</span>
            <h1>Compre com mais tranquilidade.<br /><span>Sua segurança importa.</span></h1>
            <p className="hero-description">
              Conheça orientações sobre pagamentos via Pix, devoluções e direitos do consumidor.
              Informação clara ajuda você a tomar decisões com mais confiança.
            </p>
            <div className="hero-points">
              <span><CheckCircle2 size={17} /> Orientações sobre Pix</span>
              <span><CheckCircle2 size={17} /> Direitos do consumidor</span>
              <span><CheckCircle2 size={17} /> Segurança digital</span>
            </div>
          </div>
          <div className="hero-visual" aria-label="Ilustração de proteção de pagamentos">
            <div className="orbit orbit-one" />
            <div className="orbit orbit-two" />
            <div className="shield-illustration"><ShieldCheck size={88} strokeWidth={1.25} /></div>
            <div className="floating-card card-top"><span className="mini-icon"><LockKeyhole size={17} /></span><span><b>Dados protegidos</b><small>Cuide das suas informações</small></span></div>
            <div className="floating-card card-bottom"><span className="mini-icon mint"><CheckCircle2 size={17} /></span><span><b>Mais transparência</b><small>Entenda seus direitos</small></span></div>
          </div>
        </section>

        <section className="features section-wrap">
          <div className="section-heading">
            <span className="eyebrow dark">COMPRA CONSCIENTE</span>
            <h2>Informação que ajuda a proteger você</h2>
            <p>Saiba o que conferir antes de pagar e como agir se algo não sair como esperado.</p>
          </div>
          <div className="feature-grid">
            <Feature icon={WalletCards} title="Pagamento via Pix">Confira o nome do beneficiário, o valor e os dados da compra antes de confirmar a transação.</Feature>
            <Feature icon={BadgeCheck} title="Direitos do consumidor">Entenda orientações sobre arrependimento, cancelamentos e produtos não recebidos.</Feature>
            <Feature icon={LockKeyhole} title="Segurança e privacidade">Proteja suas senhas, guarde comprovantes e tenha cuidado com links e mensagens suspeitas.</Feature>
          </div>
        </section>

        <section className="process-section">
          <div className="section-wrap">
            <div className="section-heading">
              <span className="eyebrow dark">PASSO A PASSO</span>
              <h2>Como se preparar para uma compra segura</h2>
              <p>Alguns cuidados simples ajudam você a manter registros e saber onde buscar orientação.</p>
            </div>
            <div className="steps-grid">
              <Step number="01" icon={ClipboardCheck} title="Confira sua compra">Leia a descrição do produto, confirme o preço, a entrega e as condições informadas pelo vendedor.</Step>
              <Step number="02" icon={PackageCheck} title="Guarde os comprovantes">Mantenha o comprovante Pix, a confirmação do pedido, o anúncio e as conversas com o fornecedor.</Step>
              <Step number="03" icon={CircleHelp} title="Saiba como agir">Se houver um problema, documente o ocorrido e procure o fornecedor e a instituição responsável pelo pagamento.</Step>
            </div>
          </div>
        </section>

        <section className="returns section-wrap" id="devolucoes">
          <div className="section-heading align-left">
            <span className="eyebrow dark">SEUS DIREITOS</span>
            <h2>Devolução e reembolso</h2>
            <p>As medidas possíveis dependem das circunstâncias da compra, da legislação e das condições efetivamente oferecidas pelo fornecedor.</p>
          </div>
          <div className="accordion-list">
            <details className="accordion" open>
              <summary><span className="summary-icon"><FileText size={19} /></span><span><b>Direito de arrependimento</b><small>Compras realizadas pela internet</small></span><ChevronDown size={19} className="chevron" /></summary>
              <div className="accordion-body">
                Nas compras realizadas fora do estabelecimento comercial, como pela internet, o artigo 49 do Código de Defesa do Consumidor prevê, nas situações abrangidas pela lei, prazo de sete dias para arrependimento, contado conforme a legislação. Consulte o texto legal e registre sua solicitação junto ao fornecedor.
                <a href={officialLinks.consumerLaw} target="_blank" rel="noreferrer">Consultar o Código de Defesa do Consumidor <ExternalLink size={14} /></a>
              </div>
            </details>
            <details className="accordion">
              <summary><span className="summary-icon"><PackageCheck size={19} /></span><span><b>Produto não recebido</b><small>Registre o pedido e procure o fornecedor</small></span><ChevronDown size={19} className="chevron" /></summary>
              <div className="accordion-body">
                Guarde a confirmação do pedido, a previsão de entrega e os comprovantes. Entre em contato com o fornecedor e solicite uma solução conforme os direitos previstos na legislação aplicável.
              </div>
            </details>
            <details className="accordion">
              <summary><span className="summary-icon"><ShieldAlert size={19} /></span><span><b>Produto com defeito ou diferente do anúncio</b><small>Documente o problema</small></span><ChevronDown size={19} className="chevron" /></summary>
              <div className="accordion-body">
                Fotografe ou registre o problema e guarde a descrição original do anúncio. As soluções disponíveis, que podem incluir reparação, substituição ou restituição de valores, dependem do caso e das regras legais aplicáveis.
              </div>
            </details>
            <details className="accordion">
              <summary><span className="summary-icon"><WalletCards size={19} /></span><span><b>Reembolso de pagamentos via Pix</b><small>Entenda as limitações do mecanismo</small></span><ChevronDown size={19} className="chevron" /></summary>
              <div className="accordion-body">
                O Pix não oferece chargeback comercial automático. Em caso de suspeita de golpe ou fraude, contate imediatamente sua instituição financeira e pergunte sobre as medidas disponíveis, incluindo o Mecanismo Especial de Devolução (MED), quando cabível. O MED não se destina a resolver simples desacordos comerciais e não garante que os valores serão recuperados.
                <a href={officialLinks.pix} target="_blank" rel="noreferrer">Ler orientações do Banco Central <ExternalLink size={14} /></a>
              </div>
            </details>
          </div>
          <p className="legal-note"><ShieldCheck size={18} /> As orientações desta página não substituem a análise de cada caso nem os direitos assegurados pela legislação.</p>
        </section>

        <section className="security-section">
          <div className="section-wrap security-layout">
            <div className="security-copy">
              <span className="eyebrow">SEGURANÇA DIGITAL</span>
              <h2>Sua segurança começa com informação.</h2>
              <p>Cuide dos seus dados em cada etapa da compra. Confira o endereço do site, verifique o beneficiário antes de confirmar o Pix e nunca compartilhe senhas ou códigos de autenticação.</p>
              <a className="text-link" href={officialLinks.pix} target="_blank" rel="noreferrer">Saiba mais sobre a segurança do Pix <ArrowUpRight size={17} /></a>
            </div>
            <div className="security-list">
              <div><span className="security-icon"><LockKeyhole size={20} /></span><span><b>Proteja suas credenciais</b><small>Não compartilhe senhas nem códigos de autenticação.</small></span></div>
              <div><span className="security-icon"><ShieldCheck size={20} /></span><span><b>Confira antes de pagar</b><small>Verifique o nome do beneficiário e o valor da transação.</small></span></div>
              <div><span className="security-icon"><ClipboardCheck size={20} /></span><span><b>Guarde os registros</b><small>Preserve comprovantes, anúncios e conversas importantes.</small></span></div>
            </div>
          </div>
        </section>

        <section className="regulation section-wrap">
          <div className="regulation-card">
            <div className="regulation-icon"><BadgeCheck size={27} /></div>
            <div>
              <span className="eyebrow dark">INFORMAÇÃO REGULATÓRIA</span>
              <h2>Transparência nas transações</h2>
              <p>O Banco Central publica informações sobre o Pix e disponibiliza uma ferramenta para consulta de instituições autorizadas. A autorização de uma instituição, por si só, não significa que o Banco Central garanta ou reembolse todas as compras realizadas por meio dela.</p>
              <a className="text-link" href={officialLinks.institutions} target="_blank" rel="noreferrer">Consultar instituições no Banco Central <ArrowUpRight size={17} /></a>
            </div>
          </div>
        </section>

        <section className="terms section-wrap" id="termos">
          <div className="section-heading align-left">
            <span className="eyebrow dark">TRANSPARÊNCIA</span>
            <h2>Termos e condições</h2>
          </div>
          <div className="terms-panel">
            <p>Esta página tem finalidade informativa e não cria, por si só, cobertura de seguro, garantia financeira ou compromisso de reembolso por parte da GladePay ou do Banco Central.</p>
            <p>As condições específicas de qualquer programa comercial de Compra Garantida — incluindo elegibilidade, exclusões, responsáveis pela análise e prazos — devem ser consultadas nos termos oficiais da empresa responsável, quando disponibilizados e confirmados.</p>
            <p>O tratamento de dados pessoais deve observar a legislação aplicável, incluindo a Lei Geral de Proteção de Dados (LGPD). Consulte a política de privacidade oficial da empresa responsável quando disponível.</p>
          </div>
        </section>
      </main>

      <footer className="footer">
        <div className="footer-inner">
          <a className="brand footer-brand" href="#inicio" aria-label="Voltar ao início">
            <span className="brand-mark"><ShieldCheck size={21} /></span>
            <span className="brand-copy"><strong>GladePay</strong><small>COMPRA GARANTIDA</small></span>
          </a>
          <p>Informação clara para compras mais conscientes.</p>
          <div className="footer-links">
            <a href={officialLinks.pix} target="_blank" rel="noreferrer">Segurança do Pix</a>
            <a href={officialLinks.consumerLaw} target="_blank" rel="noreferrer">Direitos do consumidor</a>
            <a href={officialLinks.institutions} target="_blank" rel="noreferrer">Consulta ao Banco Central</a>
          </div>
        </div>
        <div className="footer-bottom">© {new Date().getFullYear()} GladePay Compra Garantida. Informações sujeitas à legislação aplicável.</div>
      </footer>
    </div>
  )
}

createRoot(document.getElementById('root')).render(<App />)
